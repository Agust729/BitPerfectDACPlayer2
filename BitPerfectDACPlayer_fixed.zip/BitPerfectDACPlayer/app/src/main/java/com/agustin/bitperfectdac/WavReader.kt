package com.agustin.bitperfectdac

import android.media.AudioFormat
import java.nio.ByteBuffer
import java.nio.ByteOrder

object WavReader {
    data class WavPcm(
        val sampleRate: Int,
        val channels: Int,
        val bitDepth: Int,
        val blockAlign: Int,
        val pcmData: ByteArray
    ) {
        val encoding: Int = when (bitDepth) {
            16 -> AudioFormat.ENCODING_PCM_16BIT
            24 -> AudioFormat.ENCODING_PCM_24BIT_PACKED
            else -> error("Bit depth no soportado: $bitDepth")
        }

        val channelMask: Int = when (channels) {
            1 -> AudioFormat.CHANNEL_OUT_MONO
            2 -> AudioFormat.CHANNEL_OUT_STEREO
            else -> error("Canales no soportados en este MVP: $channels")
        }

        fun audioFormat(): AudioFormat = AudioFormat.Builder()
            .setEncoding(encoding)
            .setSampleRate(sampleRate)
            .setChannelMask(channelMask)
            .build()
    }

    fun parse(file: ByteArray): WavPcm {
        require(file.size >= 44) { "Archivo demasiado pequeño para ser WAV" }
        require(file.ascii(0, 4) == "RIFF") { "No es RIFF/WAV" }
        require(file.ascii(8, 4) == "WAVE") { "No es WAVE" }

        var cursor = 12
        var audioFormatCode = -1
        var channels = -1
        var sampleRate = -1
        var bitsPerSample = -1
        var blockAlign = -1
        var dataOffset = -1
        var dataSize = -1

        while (cursor + 8 <= file.size) {
            val chunkId = file.ascii(cursor, 4)
            val chunkSize = file.leInt(cursor + 4)
            val chunkData = cursor + 8
            if (chunkData + chunkSize > file.size) break

            when (chunkId) {
                "fmt " -> {
                    audioFormatCode = file.leShort(chunkData).toInt() and 0xffff
                    channels = file.leShort(chunkData + 2).toInt() and 0xffff
                    sampleRate = file.leInt(chunkData + 4)
                    blockAlign = file.leShort(chunkData + 12).toInt() and 0xffff
                    bitsPerSample = file.leShort(chunkData + 14).toInt() and 0xffff
                }
                "data" -> {
                    dataOffset = chunkData
                    dataSize = chunkSize
                }
            }

            cursor = chunkData + chunkSize + (chunkSize and 1)
        }

        require(audioFormatCode == 1) { "Solo WAV PCM sin comprimir. Código encontrado: $audioFormatCode" }
        require(channels == 1 || channels == 2) { "Este MVP soporta mono o stereo. Canales: $channels" }
        require(bitsPerSample == 16 || bitsPerSample == 24) { "Este MVP soporta 16 o 24-bit PCM. Bits: $bitsPerSample" }
        require(sampleRate > 0) { "Sample rate inválido" }
        require(dataOffset >= 0 && dataSize > 0) { "No encontré chunk data" }

        val pcm = file.copyOfRange(dataOffset, dataOffset + dataSize)
        return WavPcm(sampleRate, channels, bitsPerSample, blockAlign, pcm)
    }

    private fun ByteArray.ascii(offset: Int, length: Int): String =
        String(this, offset, length, Charsets.US_ASCII)

    private fun ByteArray.leInt(offset: Int): Int =
        ByteBuffer.wrap(this, offset, 4).order(ByteOrder.LITTLE_ENDIAN).int

    private fun ByteArray.leShort(offset: Int): Short =
        ByteBuffer.wrap(this, offset, 2).order(ByteOrder.LITTLE_ENDIAN).short
}

package com.agustin.bitperfectdac

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioMixerAttributes
import android.media.AudioTrack
import android.net.Uri
import android.os.Build
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

class BitPerfectAudioEngine(
    private val context: Context,
    private val onStatus: (String) -> Unit
) {
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val playing = AtomicBoolean(false)
    private var audioTrack: AudioTrack? = null
    private var playThread: Thread? = null

    private val mediaAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()

    fun describeUsbStatus(): String {
        val usb = findUsbOutputDevice()
        return if (usb == null) {
            "DAC USB: no detectado. Conectá uno por OTG/USB-C."
        } else {
            "DAC USB detectado: ${usb.productName ?: usb.typeName()}"
        }
    }

    fun play(uri: Uri) {
        stop()
        playing.set(true)
        playThread = thread(name = "bit-perfect-playback") {
            try {
                onStatus("Leyendo WAV…")
                val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    ?: error("No pude abrir el archivo")
                val wav = WavReader.parse(bytes)

                val usbDevice = findUsbOutputDevice()
                if (usbDevice == null) {
                    onStatus("Sin DAC USB. Reproduciendo por salida normal; NO es bit-perfect garantizado.")
                }

                val desiredFormat = wav.audioFormat()
                val mixer = chooseMixerAttributes(usbDevice, desiredFormat)
                val formatForTrack = mixer?.format ?: desiredFormat
                val modeText = when {
                    mixer?.mixerBehavior == AudioMixerAttributes.MIXER_BEHAVIOR_BIT_PERFECT -> "BIT_PERFECT"
                    mixer != null -> "mixer USB con sample-rate matching, no bit-perfect"
                    else -> "modo normal Android"
                }

                val preferredApplied = if (usbDevice != null && mixer != null && Build.VERSION.SDK_INT >= 34) {
                    audioManager.setPreferredMixerAttributes(mediaAttributes, usbDevice, mixer)
                } else false

                val minBuffer = AudioTrack.getMinBufferSize(
                    wav.sampleRate,
                    wav.channelMask,
                    wav.encoding
                ).coerceAtLeast(wav.blockAlign * 4096)

                val track = AudioTrack.Builder()
                    .setAudioAttributes(mediaAttributes)
                    .setAudioFormat(formatForTrack)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .setBufferSizeInBytes(minBuffer * 2)
                    .build()

                audioTrack = track
                onStatus(
                    "Reproduciendo: ${wav.sampleRate} Hz / ${wav.bitDepth}-bit / ${wav.channels} ch\n" +
                        "Salida: $modeText | Preferred aplicado: $preferredApplied"
                )
                track.play()

                var offset = 0
                val chunkSize = 64 * 1024
                while (playing.get() && offset < wav.pcmData.size) {
                    val count = minOf(chunkSize, wav.pcmData.size - offset)
                    val written = track.write(wav.pcmData, offset, count)
                    if (written < 0) error("AudioTrack.write falló: $written")
                    offset += written
                }

                track.stop()
                track.release()
                audioTrack = null

                if (usbDevice != null && Build.VERSION.SDK_INT >= 34) {
                    audioManager.clearPreferredMixerAttributes(mediaAttributes, usbDevice)
                }

                if (playing.get()) onStatus("Finalizó la reproducción")
            } catch (t: Throwable) {
                onStatus("Error: ${t.message}")
                audioTrack?.release()
                audioTrack = null
            } finally {
                playing.set(false)
            }
        }
    }

    fun stop() {
        playing.set(false)
        try {
            audioTrack?.pause()
            audioTrack?.flush()
            audioTrack?.release()
        } catch (_: Throwable) {
        }
        audioTrack = null
        playThread = null
    }

    private fun findUsbOutputDevice(): AudioDeviceInfo? {
        return audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS).firstOrNull { device ->
            device.type == AudioDeviceInfo.TYPE_USB_DEVICE ||
                device.type == AudioDeviceInfo.TYPE_USB_HEADSET
        }
    }

    private fun chooseMixerAttributes(
        usbDevice: AudioDeviceInfo?,
        desiredFormat: AudioFormat
    ): AudioMixerAttributes? {
        if (usbDevice == null || Build.VERSION.SDK_INT < 34) return null

        val supported = audioManager.getSupportedMixerAttributes(usbDevice)
        if (supported.isEmpty()) return null

        fun AudioFormat.sameFormatAs(other: AudioFormat): Boolean {
            return sampleRate == other.sampleRate &&
                encoding == other.encoding &&
                channelMask == other.channelMask
        }

        val exactBitPerfect = supported.firstOrNull { attr ->
            attr.mixerBehavior == AudioMixerAttributes.MIXER_BEHAVIOR_BIT_PERFECT &&
                attr.format.sameFormatAs(desiredFormat)
        }
        if (exactBitPerfect != null) return exactBitPerfect

        val exactDefault = supported.firstOrNull { attr ->
            attr.format.sameFormatAs(desiredFormat)
        }
        return exactDefault
    }

    private fun AudioDeviceInfo.typeName(): String = when (type) {
        AudioDeviceInfo.TYPE_USB_DEVICE -> "USB device"
        AudioDeviceInfo.TYPE_USB_HEADSET -> "USB headset"
        else -> "tipo $type"
    }
}

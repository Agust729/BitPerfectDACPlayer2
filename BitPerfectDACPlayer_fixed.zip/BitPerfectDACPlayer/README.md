# BitPerfect DAC Player

MVP de reproductor local para Android con salida USB DAC usando `AudioMixerAttributes` en Android 14+.

## Qué hace

- Reproduce archivos WAV PCM locales.
- Soporta WAV PCM 16-bit y 24-bit packed.
- Soporta mono/stereo.
- Detecta salida USB tipo `TYPE_USB_DEVICE` o `TYPE_USB_HEADSET`.
- En Android 14+ consulta `getSupportedMixerAttributes()`.
- Si el DAC/ROM/HAL exponen un formato exacto con `MIXER_BEHAVIOR_BIT_PERFECT`, aplica `setPreferredMixerAttributes()` antes de reproducir.
- Si no hay soporte, reproduce por `AudioTrack` en modo normal o sample-rate matching, pero no promete bit-perfect.

## Limitaciones importantes

Esto NO es todavía un reemplazo de UAPP/HiBy:

- No reproduce FLAC/ALAC/MP3 todavía.
- No tiene biblioteca musical, carátulas ni playlists.
- No implementa driver USB Audio Class 2.0 propio.
- El bit-perfect depende del soporte real de Android/ROM/HAL/DAC.
- Para bit-perfect no debe haber EQ, normalización, crossfade, ReplayGain, Dolby, Viper, JamesDSP ni volumen digital modificado.

## Requisitos

- Android Studio reciente.
- Android 14+ para intentar `BIT_PERFECT`.
- DAC USB por OTG/USB-C.
- Archivo WAV PCM 16/24-bit.

## Cómo abrir

1. Abrí Android Studio.
2. Elegí `Open` y seleccioná esta carpeta.
3. Esperá la sincronización de Gradle.
4. Instalá en el teléfono.
5. Conectá el DAC USB.
6. Abrí la app y elegí un archivo WAV.

## Próximos pasos recomendados

1. Agregar decodificador FLAC nativo, por ejemplo libFLAC o FFmpeg, y entregar PCM sin DSP.
2. Agregar lectura por streaming para no cargar el WAV entero en RAM.
3. Agregar pantalla de formatos soportados por el DAC.
4. Agregar verificación de `BIT_PERFECT` y aviso claro si la ROM no lo soporta.
5. Agregar cola de reproducción, biblioteca musical, carátulas y búsqueda.
6. Para soporte Android viejo o ROMs sin bit-perfect oficial, implementar driver USB Audio Class 2.0 propio desde `UsbManager`; eso es mucho más complejo.

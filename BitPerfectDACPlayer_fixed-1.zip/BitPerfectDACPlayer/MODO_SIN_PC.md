# Cómo compilar sin PC

El ZIP es código fuente. Para instalarlo en Android hay que convertirlo en APK.

## Opción recomendada: GitHub Actions desde el celular

1. Creá una cuenta en GitHub o iniciá sesión.
2. Creá un repositorio nuevo, por ejemplo `BitPerfectDACPlayer`.
3. Subí todo el contenido de esta carpeta al repositorio.
4. Entrá a la pestaña **Actions**.
5. Elegí **Build APK**.
6. Tocá **Run workflow**.
7. Cuando termine, abrí el resultado y descargá el artifact llamado `BitPerfectDACPlayer-debug-apk`.
8. Dentro estará el APK debug para instalar en tu Android.

Aviso: Android puede pedirte permitir instalación de apps desconocidas.

## Opción alternativa: AndroidIDE en el propio celular

Puede compilar proyectos Gradle desde Android, pero el proyecto AndroidIDE aparece marcado como no mantenido, así que puede fallar con SDK/Gradle modernos.

## Opción poco recomendable: Termux

Se puede intentar, pero instalar Android SDK + Gradle desde Termux es pesado y suele traer problemas en celulares.

package com.agustin.bitperfectdac

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var statusText: TextView
    private lateinit var fileText: TextView
    private lateinit var playButton: Button
    private lateinit var stopButton: Button
    private lateinit var engine: BitPerfectAudioEngine

    private var selectedUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        engine = BitPerfectAudioEngine(this) { message ->
            runOnUiThread { statusText.text = message }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(36, 56, 36, 36)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        val title = TextView(this).apply {
            text = "BitPerfect DAC Player"
            textSize = 26f
            gravity = Gravity.CENTER
        }

        val hint = TextView(this).apply {
            text = "MVP local: WAV PCM y FLAC. Conectá un DAC USB y elegí un archivo. En Android 14+ intenta usar BIT_PERFECT por AudioMixerAttributes."
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 28)
        }

        fileText = TextView(this).apply {
            text = "Archivo: ninguno"
            textSize = 15f
            setPadding(0, 0, 0, 20)
        }

        statusText = TextView(this).apply {
            text = engine.describeUsbStatus()
            textSize = 14f
            setPadding(0, 0, 0, 24)
        }

        val pickButton = Button(this).apply {
            text = "Elegir audio"
            setOnClickListener { openFilePicker() }
        }

        playButton = Button(this).apply {
            text = "Reproducir"
            isEnabled = false
            setOnClickListener {
                val uri = selectedUri ?: return@setOnClickListener
                engine.play(uri)
            }
        }

        stopButton = Button(this).apply {
            text = "Detener"
            setOnClickListener { engine.stop() }
        }

        root.addView(title)
        root.addView(hint)
        root.addView(fileText)
        root.addView(statusText)
        root.addView(pickButton)
        root.addView(playButton)
        root.addView(stopButton)
        setContentView(root)
    }

    override fun onDestroy() {
        engine.stop()
        super.onDestroy()
    }

    @Deprecated("Usado para mantener el proyecto sin dependencias AndroidX")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_OPEN_AUDIO && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            selectedUri = uri
            fileText.text = "Archivo: ${displayName(uri)}"
            playButton.isEnabled = true
            Toast.makeText(this, "Archivo seleccionado", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openFilePicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, REQ_OPEN_AUDIO)
    }

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && index >= 0) return cursor.getString(index)
        }
        return uri.lastPathSegment ?: "audio.wav"
    }

    companion object {
        private const val REQ_OPEN_AUDIO = 1001
    }
}

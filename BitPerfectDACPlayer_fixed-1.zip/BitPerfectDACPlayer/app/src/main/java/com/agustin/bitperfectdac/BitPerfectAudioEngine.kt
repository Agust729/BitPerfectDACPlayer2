package com.agustin.bitperfectdac

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioMixerAttributes
import android.media.AudioTrack
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.os.Build
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

class BitPerfectAudioEngine(
    private val context: Context,
    private val onStatus: (String) -> Unit
) {
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val playing = AtomicBoolean(false)
    private var audioTrack: AudioTrack? = null
    private var playThread: Thread? = null

    private val mediaAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()

    fun describeUsbStatus(): String {
        val usb = findUsbOutputDevice()
        return if (usb == null) {
            "DAC USB: no detectado. Conectá uno por OTG/USB-C."
        } else {
            "DAC USB detectado: ${usb.productName ?: usb.typeName()}"
        }
    }

    fun play(uri: Uri) {
        stop()
        playing.set(true)
        playThread = thread(name = "bit-perfect-playback") {
            try {
                onStatus("Leyendo archivo…")
                val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    ?: error("No pude abrir el archivo")

                if (WavReader.looksLikeWav(bytes)) {
                    playWav(bytes)
                } else {
                    playDecodedAudio(uri)
                }
            } catch (t: Throwable) {
                onStatus("Error: ${t.message}")
                safeReleaseTrack()
            } finally {
                playing.set(false)
            }
        }
    }

    private fun playWav(bytes: ByteArray) {
        val wav = WavReader.parse(bytes)
        val desiredFormat = wav.audioFormat()
        val setup = prepareTrack(
            sampleRate = wav.sampleRate,
            channels = wav.channels,
            encoding = wav.encoding,
            desiredFormat = desiredFormat,
            minBytes = wav.blockAlign * 4096
        )

        val track = setup.track
        audioTrack = track
        onStatus(
            "Reproduciendo WAV: ${wav.sampleRate} Hz / ${wav.bitDepth}-bit / ${wav.channels} ch\n" +
                "Salida: ${setup.modeText} | Preferred aplicado: ${setup.preferredApplied}"
        )
        track.play()

        var offset = 0
        val chunkSize = 64 * 1024
        while (playing.get() && offset < wav.pcmData.size) {
            val count = minOf(chunkSize, wav.pcmData.size - offset)
            val written = track.write(wav.pcmData, offset, count)
            if (written < 0) error("AudioTrack.write falló: $written")
            offset += written
        }

        finishPlayback(setup.usbDevice)
    }

    private fun playDecodedAudio(uri: Uri) {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
                if (afd.length >= 0) {
                    extractor.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                } else {
                    extractor.setDataSource(afd.fileDescriptor)
                }
            } ?: error("No pude abrir el archivo")

            val trackIndex = (0 until extractor.trackCount).firstOrNull { index ->
                val mime = extractor.getTrackFormat(index).getString(MediaFormat.KEY_MIME) ?: ""
                mime.startsWith("audio/")
            } ?: error("No encontré pista de audio")

            extractor.selectTrack(trackIndex)
            val inputFormat = extractor.getTrackFormat(trackIndex)
            val mime = inputFormat.getString(MediaFormat.KEY_MIME) ?: error("Formato desconocido")

            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(inputFormat, null, null, 0)
            codec.start()

            val info = MediaCodec.BufferInfo()
            var inputEnded = false
            var outputEnded = false
            var trackStarted = false
            var setup: TrackSetup? = null

            fun startTrackFrom(format: MediaFormat) {
                if (trackStarted) return

                val sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                val channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                val encoding = if (format.containsKey(MediaFormat.KEY_PCM_ENCODING)) {
                    format.getInteger(MediaFormat.KEY_PCM_ENCODING)
                } else {
                    AudioFormat.ENCODING_PCM_16BIT
                }

                val channelMask = channelMaskFor(channels)
                val audioFormat = AudioFormat.Builder()
                    .setEncoding(encoding)
                    .setSampleRate(sampleRate)
                    .setChannelMask(channelMask)
                    .build()

                setup = prepareTrack(
                    sampleRate = sampleRate,
                    channels = channels,
                    encoding = encoding,
                    desiredFormat = audioFormat,
                    minBytes = 64 * 1024
                )

                audioTrack = setup!!.track
                audioTrack!!.play()
                trackStarted = true

                val losslessText = if (mime == "audio/flac") {
                    "FLAC decodificado a PCM"
                } else {
                    "Audio decodificado a PCM ($mime)"
                }

                onStatus(
                    "Reproduciendo: $losslessText\n" +
                        "$sampleRate Hz / ${encodingName(encoding)} / $channels ch\n" +
                        "Salida: ${setup!!.modeText} | Preferred aplicado: ${setup!!.preferredApplied}"
                )
            }

            while (playing.get() && !outputEnded) {
                if (!inputEnded) {
                    val inputIndex = codec.dequeueInputBuffer(10_000)
                    if (inputIndex >= 0) {
                        val inputBuffer = codec.getInputBuffer(inputIndex) ?: error("Input buffer nulo")
                        val sampleSize = extractor.readSampleData(inputBuffer, 0)
                        if (sampleSize < 0) {
                            codec.queueInputBuffer(
                                inputIndex,
                                0,
                                0,
                                0,
                                MediaCodec.BUFFER_FLAG_END_OF_STREAM
                            )
                            inputEnded = true
                        } else {
                            codec.queueInputBuffer(
                                inputIndex,
                                0,
                                sampleSize,
                                extractor.sampleTime,
                                0
                            )
                            extractor.advance()
                        }
                    }
                }

                when (val outputIndex = codec.dequeueOutputBuffer(info, 10_000)) {
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        startTrackFrom(codec.outputFormat)
                    }
                    MediaCodec.INFO_TRY_AGAIN_LATER -> {
                        // Esperar más datos.
                    }
                    else -> if (outputIndex >= 0) {
                        if (!trackStarted) startTrackFrom(codec.outputFormat)

                        val outputBuffer = codec.getOutputBuffer(outputIndex)
                        if (outputBuffer != null && info.size > 0) {
                            outputBuffer.position(info.offset)
                            outputBuffer.limit(info.offset + info.size)
                            while (playing.get() && outputBuffer.hasRemaining()) {
                                val written = audioTrack!!.write(
                                    outputBuffer,
                                    outputBuffer.remaining(),
                                    AudioTrack.WRITE_BLOCKING
                                )
                                if (written < 0) error("AudioTrack.write falló: $written")
                            }
                        }

                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                            outputEnded = true
                        }
                        codec.releaseOutputBuffer(outputIndex, false)
                    }
                }
            }

            finishPlayback(setup?.usbDevice)
        } finally {
            codec?.stop()
            codec?.release()
            extractor.release()
        }
    }

    fun stop() {
        playing.set(false)
        safeReleaseTrack()
        playThread = null
    }

    private fun safeReleaseTrack() {
        try {
            audioTrack?.pause()
            audioTrack?.flush()
            audioTrack?.release()
        } catch (_: Throwable) {
        }
        audioTrack = null
    }

    private fun finishPlayback(usbDevice: AudioDeviceInfo?) {
        try {
            audioTrack?.stop()
        } catch (_: Throwable) {
        }
        safeReleaseTrack()

        if (usbDevice != null && Build.VERSION.SDK_INT >= 34) {
            audioManager.clearPreferredMixerAttributes(mediaAttributes, usbDevice)
        }

        if (playing.get()) onStatus("Finalizó la reproducción")
    }

    private data class TrackSetup(
        val track: AudioTrack,
        val usbDevice: AudioDeviceInfo?,
        val preferredApplied: Boolean,
        val modeText: String
    )

    private fun prepareTrack(
        sampleRate: Int,
        channels: Int,
        encoding: Int,
        desiredFormat: AudioFormat,
        minBytes: Int
    ): TrackSetup {
        val usbDevice = findUsbOutputDevice()
        if (usbDevice == null) {
            onStatus("Sin DAC USB. Reproduciendo por salida normal; NO es bit-perfect garantizado.")
        }

        val mixer = chooseMixerAttributes(usbDevice, desiredFormat)
        val formatForTrack = mixer?.format ?: desiredFormat
        val modeText = when {
            mixer?.mixerBehavior == AudioMixerAttributes.MIXER_BEHAVIOR_BIT_PERFECT -> "BIT_PERFECT"
            mixer != null -> "mixer USB con sample-rate matching, no bit-perfect"
            else -> "modo normal Android"
        }

        val preferredApplied = if (usbDevice != null && mixer != null && Build.VERSION.SDK_INT >= 34) {
            audioManager.setPreferredMixerAttributes(mediaAttributes, usbDevice, mixer)
        } else false

        val minBuffer = AudioTrack.getMinBufferSize(
            sampleRate,
            channelMaskFor(channels),
            encoding
        ).coerceAtLeast(minBytes)

        val track = AudioTrack.Builder()
            .setAudioAttributes(mediaAttributes)
            .setAudioFormat(formatForTrack)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setBufferSizeInBytes(minBuffer * 2)
            .build()

        return TrackSetup(track, usbDevice, preferredApplied, modeText)
    }

    private fun findUsbOutputDevice(): AudioDeviceInfo? {
        return audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS).firstOrNull { device ->
            device.type == AudioDeviceInfo.TYPE_USB_DEVICE ||
                device.type == AudioDeviceInfo.TYPE_USB_HEADSET
        }
    }

    private fun chooseMixerAttributes(
        usbDevice: AudioDeviceInfo?,
        desiredFormat: AudioFormat
    ): AudioMixerAttributes? {
        if (usbDevice == null || Build.VERSION.SDK_INT < 34) return null

        val supported = audioManager.getSupportedMixerAttributes(usbDevice)
        if (supported.isEmpty()) return null

        fun AudioFormat.sameFormatAs(other: AudioFormat): Boolean {
            return sampleRate == other.sampleRate &&
                encoding == other.encoding &&
                channelMask == other.channelMask
        }

        val exactBitPerfect = supported.firstOrNull { attr ->
            attr.mixerBehavior == AudioMixerAttributes.MIXER_BEHAVIOR_BIT_PERFECT &&
                attr.format.sameFormatAs(desiredFormat)
        }
        if (exactBitPerfect != null) return exactBitPerfect

        val exactDefault = supported.firstOrNull { attr ->
            attr.format.sameFormatAs(desiredFormat)
        }
        return exactDefault
    }

    private fun channelMaskFor(channels: Int): Int = when (channels) {
        1 -> AudioFormat.CHANNEL_OUT_MONO
        2 -> AudioFormat.CHANNEL_OUT_STEREO
        else -> error("Canales no soportados en este MVP: $channels")
    }

    private fun encodingName(encoding: Int): String = when (encoding) {
        AudioFormat.ENCODING_PCM_16BIT -> "16-bit PCM"
        AudioFormat.ENCODING_PCM_24BIT_PACKED -> "24-bit PCM"
        AudioFormat.ENCODING_PCM_32BIT -> "32-bit PCM"
        AudioFormat.ENCODING_PCM_FLOAT -> "PCM float"
        else -> "PCM encoding $encoding"
    }

    private fun AudioDeviceInfo.typeName(): String = when (type) {
        AudioDeviceInfo.TYPE_USB_DEVICE -> "USB device"
        AudioDeviceInfo.TYPE_USB_HEADSET -> "USB headset"
        else -> "tipo $type"
    }
}

# BitPerfect DAC Player

MVP de reproductor local para Android con salida USB DAC usando `AudioMixerAttributes` en Android 14+.

## Qué hace

- Reproduce archivos WAV PCM locales.
- Reproduce FLAC usando el decodificador de Android y entrega PCM a `AudioTrack`.
- Soporta mono/stereo.
- Detecta salida USB tipo `TYPE_USB_DEVICE` o `TYPE_USB_HEADSET`.
- En Android 14+ consulta `getSupportedMixerAttributes()`.
- Si el DAC/ROM/HAL exponen un formato exacto con `MIXER_BEHAVIOR_BIT_PERFECT`, aplica `setPreferredMixerAttributes()` antes de reproducir.
- Si no hay soporte, reproduce por `AudioTrack` en modo normal o sample-rate matching, pero no promete bit-perfect.

## Limitaciones importantes

Esto NO es todavía un reemplazo de UAPP/HiBy:

- No tiene biblioteca musical, carátulas ni playlists.
- No implementa driver USB Audio Class 2.0 propio.
- El bit-perfect depende del soporte real de Android/ROM/HAL/DAC.
- En FLAC, el audio se decodifica a PCM con el decodificador de Android. Si Android cambia la profundidad de bits al decodificar, la salida puede no ser bit-perfect aunque conserve el sample rate.
- Para bit-perfect no debe haber EQ, normalización, crossfade, ReplayGain, Dolby, Viper, JamesDSP ni volumen digital modificado.

## Requisitos

- Android Studio reciente o GitHub Actions.
- Android 14+ para intentar `BIT_PERFECT`.
- DAC USB por OTG/USB-C.
- Archivo WAV PCM o FLAC.
